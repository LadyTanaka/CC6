import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax2nc9 (1:307)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff8c8dc),
          borderRadius: BorderRadius.circular(50*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbariphone13Wo3 (1:308)
              padding: EdgeInsets.fromLTRB(34*fem, 0*fem, 33.6*fem, 0*fem),
              width: double.infinity,
              height: 63*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftsidedMs (I1:308;708:6584)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 45*fem, 26*fem),
                    width: 54*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24*fem),
                    ),
                    child: Container(
                      // statusbartimexf3 (I1:308;708:6585)
                      padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 12*fem, 0*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24*fem),
                      ),
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2941176471*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff010101),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // notchS4R (I1:308;701:5663)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 33*fem),
                    width: 164*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/notch-joP.png',
                      width: 164*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // rightsidejpD (I1:308;708:8722)
                    margin: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 31*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iconmobilesignal4Lh (I1:308;708:9720)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 18*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-mobile-signal-wKo.png',
                            width: 18*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // wifiiAM (I1:308;708:8727)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                          width: 17*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi-iYq.png',
                            width: 17*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // batterydYD (I1:308;708:8723)
                          width: 27.4*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery-6Tb.png',
                            width: 27.4*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupr229LSd (DNZ3eQ6w8qCiaHqu6fR229)
              width: double.infinity,
              height: 869*fem,
              child: Stack(
                children: [
                  Positioned(
                    // homeindicator4dX (I1:309;5:3093)
                    left: 148*fem,
                    top: 856*fem,
                    child: Align(
                      child: SizedBox(
                        width: 134*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogrouptthkmXw (DNZ1FoRCwFUoHJtzwFtthK)
                    left: 11*fem,
                    top: 27*fem,
                    child: Container(
                      width: 392*fem,
                      height: 54*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // menusL5 (1:310)
                            margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 232*fem, 0*fem),
                            child: Text(
                              'Menu:',
                              style: SafeGoogleFont (
                                'Iceberg',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w400,
                                height: 0.55*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // ellipse2xMX (1:311)
                            width: 58*fem,
                            height: 54*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-2-brq.png',
                              width: 58*fem,
                              height: 54*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // searchfieldh4D (1:312)
                    left: 39*fem,
                    top: 127*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(8*fem, 7*fem, 8*fem, 7*fem),
                      width: 343*fem,
                      height: 36*fem,
                      decoration: BoxDecoration (
                        color: Color(0x1e767680),
                        borderRadius: BorderRadius.circular(10*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // iconmagnifyingglassAiV (I1:312;140:9380)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                            width: 15.63*fem,
                            height: 15.78*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-magnifyingglass.png',
                              width: 15.63*fem,
                              height: 15.78*fem,
                            ),
                          ),
                          Container(
                            // placeholderrLR (I1:312;26:525)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 246.49*fem, 0*fem),
                            child: Text(
                              'Search',
                              style: SafeGoogleFont (
                                'SF Pro Text',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2941176471*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0x993c3c43),
                              ),
                            ),
                          ),
                          Container(
                            // sfsymbolmicrophoneXhT (I1:312;140:9337)
                            width: 11.88*fem,
                            height: 17.68*fem,
                            child: Image.asset(
                              'assets/page-1/images/sf-symbol-microphone.png',
                              width: 11.88*fem,
                              height: 17.68*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroup5badrDw (DNZ1SiGh7N5E1PjEsY5BAd)
                    left: 11*fem,
                    top: 174*fem,
                    child: Container(
                      width: 417*fem,
                      height: 256*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupdny3kaD (DNZ2PX2hqJtQR3ivKZdny3)
                            padding: EdgeInsets.fromLTRB(35*fem, 27*fem, 37*fem, 14*fem),
                            width: 137*fem,
                            height: double.infinity,
                            child: Container(
                              // autogroupwdd7Um7 (DNZ1hYBKd3ajcszKCPWDd7)
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogrouprk7fRgM (DNZ1pXyfTbG5TZPik6Rk7F)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 62*fem),
                                    padding: EdgeInsets.fromLTRB(23*fem, 0*fem, 0*fem, 0*fem),
                                    width: double.infinity,
                                    height: 70*fem,
                                    child: Align(
                                      // rectangle3XjP (1:322)
                                      alignment: Alignment.topRight,
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 38*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            color: Color(0xffd9d9d9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // autogroupbhcy3xd (DNZ1usA7cxdmRytbpvBHcy)
                                    padding: EdgeInsets.fromLTRB(23*fem, 45*fem, 0*fem, 0*fem),
                                    width: double.infinity,
                                    child: Align(
                                      // rectangle4zcy (1:323)
                                      alignment: Alignment.bottomRight,
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 38*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            color: Color(0xffd9d9d9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupsn3wvWd (DNZ26CCEorvR1B74JPSn3w)
                            width: 280*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupajnyFYu (DNZ2CmqcE7XLsnnLENaJny)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 47*fem),
                                  width: double.infinity,
                                  height: 116*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // pf69hero1yUu (1:318)
                                        left: 40*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 215*fem,
                                            height: 93*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/pf69-hero-1.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // takoyakicheesebomb5H3 (1:319)
                                        left: 74*fem,
                                        top: 93*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 154*fem,
                                            height: 22*fem,
                                            child: Text(
                                              'Takoyaki Cheese Bomb',
                                              style: SafeGoogleFont (
                                                'Iceberg',
                                                fontSize: 17*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2941176471*ffem/fem,
                                                letterSpacing: -0.4079999924*fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // php9Gu (1:331)
                                        left: 234*fem,
                                        top: 94*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 46*fem,
                                            height: 22*fem,
                                            child: Text(
                                              '65 php',
                                              style: SafeGoogleFont (
                                                'Iceberg',
                                                fontSize: 17*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.2941176471*ffem/fem,
                                                letterSpacing: -0.4079999924*fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // n1qQd (1:320)
                                  margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 0*fem, 0*fem),
                                  width: 215*fem,
                                  height: 93*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/n-1.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogrouprgmjM85 (DNZ2ufq8ZRbXCVv2WXrGmj)
                    left: 46*fem,
                    top: 523*fem,
                    child: Container(
                      width: 357*fem,
                      height: 105*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroups1dxH1j (DNZ325p7Qky5tHhebRs1DX)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 77*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(23*fem, 40*fem, 0*fem, 0*fem),
                            width: 65*fem,
                            child: Align(
                              // rectangle5bo7 (1:324)
                              alignment: Alignment.bottomRight,
                              child: SizedBox(
                                width: double.infinity,
                                height: 38*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffd9d9d9),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // vlcsnap2021070714h33m06s4281wr (1:326)
                            margin: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 0*fem),
                            width: 215*fem,
                            height: 93*fem,
                            child: Image.asset(
                              'assets/page-1/images/vlcsnap-2021-07-07-14h33m06s428-1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupzfyySoj (DNZ3FAGexoZG377NXrZfYy)
                    left: 46*fem,
                    top: 713*fem,
                    child: Container(
                      width: 357.3*fem,
                      height: 100.9*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupe173NSV (DNZ3M5GU7PEjARE35VE173)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 77*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(23*fem, 49*fem, 0*fem, 0*fem),
                            width: 65*fem,
                            child: Align(
                              // rectangle6J5F (1:325)
                              alignment: Alignment.bottomRight,
                              child: SizedBox(
                                width: double.infinity,
                                height: 38*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffd9d9d9),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // menueditoritem965dc9ae9cb14acc (1:328)
                            width: 215.3*fem,
                            height: 100.9*fem,
                            child: Image.asset(
                              'assets/page-1/images/menueditoritem965dc9ae9cb14acc81c87a23a906ded01649166883598041310-1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroup3yaqYkH (DNZ2nqhBHo9YYeQGov3Yaq)
                    left: 231*fem,
                    top: 449*fem,
                    child: Container(
                      width: 192*fem,
                      height: 22*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // porkflosstakoyakifpu (1:321)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                            child: Text(
                              'Pork Floss Takoyaki\n',
                              style: SafeGoogleFont (
                                'Iceberg',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2941176471*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Text(
                            // phpZvH (1:332)
                            '60 php',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2941176471*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupxlmbJss (DNZ37zovZLeZ1bpK94XLmb)
                    left: 188*fem,
                    top: 636*fem,
                    child: Container(
                      width: 235*fem,
                      height: 25*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // baconandcheesetakoyaki2os (1:327)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 3*fem),
                            child: Text(
                              'Bacon and Cheese Takoyaki\n',
                              style: SafeGoogleFont (
                                'Iceberg',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2941176471*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // phpL3s (1:333)
                            margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                            child: Text(
                              '70 php',
                              style: SafeGoogleFont (
                                'Iceberg',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2941176471*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupejyqSMo (DNZ3TVFSxicHrD1fAPEjYq)
                    left: 205*fem,
                    top: 821*fem,
                    child: Container(
                      width: 187*fem,
                      height: 24*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // takoyakiplatter9n1 (1:329)
                            margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 22*fem, 0*fem),
                            child: Text(
                              'Takoyaki Platter\n\n',
                              style: SafeGoogleFont (
                                'Iceberg',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2941176471*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // phpFa9 (1:334)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                            child: Text(
                              '235 php',
                              style: SafeGoogleFont (
                                'Iceberg',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2941176471*ffem/fem,
                                letterSpacing: -0.4079999924*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}