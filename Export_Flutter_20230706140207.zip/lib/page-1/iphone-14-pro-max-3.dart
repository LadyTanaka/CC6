import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax3Noj (1:335)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff8c8dc),
          borderRadius: BorderRadius.circular(50*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbariphone13uHs (1:336)
              padding: EdgeInsets.fromLTRB(34*fem, 0*fem, 33.6*fem, 0*fem),
              width: double.infinity,
              height: 63*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftsidepQq (I1:336;708:6584)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 45*fem, 26*fem),
                    width: 54*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24*fem),
                    ),
                    child: Container(
                      // statusbartime9T7 (I1:336;708:6585)
                      padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 12*fem, 0*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24*fem),
                      ),
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2941176471*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff010101),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // notch1kD (I1:336;701:5663)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 33*fem),
                    width: 164*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/notch-iy7.png',
                      width: 164*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // rightsidevsB (I1:336;708:8722)
                    margin: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 31*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iconmobilesignals1j (I1:336;708:9720)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 18*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-mobile-signal-Y3s.png',
                            width: 18*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // wifiNUH (I1:336;708:8727)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                          width: 17*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi-ex9.png',
                            width: 17*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // batteryewb (I1:336;708:8723)
                          width: 27.4*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery-oi9.png',
                            width: 27.4*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupdttd8bs (DNZ7QsfEUUvHsCKBasdttD)
              padding: EdgeInsets.fromLTRB(11*fem, 27*fem, 10*fem, 8*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouptx1bLhw (DNZ5hkqinQowouRw1Ntx1b)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 74*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // menusC5 (1:338)
                          margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 232*fem, 0*fem),
                          child: Text(
                            'Menu:',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 40*ffem,
                              fontWeight: FontWeight.w400,
                              height: 0.55*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // ellipse2Ned (1:339)
                          width: 58*fem,
                          height: 54*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2.png',
                            width: 58*fem,
                            height: 54*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroups4kxJ2V (DNZ5rLRm1gBFvRo36RS4KX)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 13*fem, 45*fem),
                    width: double.infinity,
                    height: 132*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupaktfR77 (DNZ62VoVdfEYJo7qioakTF)
                          margin: EdgeInsets.fromLTRB(0*fem, 46*fem, 37*fem, 16*fem),
                          padding: EdgeInsets.fromLTRB(23*fem, 0*fem, 0*fem, 0*fem),
                          width: 65*fem,
                          height: double.infinity,
                          child: Align(
                            // rectangle3jtV (1:347)
                            alignment: Alignment.topRight,
                            child: SizedBox(
                              width: double.infinity,
                              height: 38*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup6hnvH9K (DNZ67VfAfC9VuZqR7T6hNV)
                          width: 259*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // shrimptakoyakipf3 (1:345)
                                left: 88*fem,
                                top: 110*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 114*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'Shrimp Takoyaki\n',
                                      style: SafeGoogleFont (
                                        'Iceberg',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2941176471*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // takoyakiwithshrimp15ay (1:353)
                                left: 33*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 215*fem,
                                    height: 93*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/takoyaki-with-shrimp-1.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // phpzhw (1:359)
                                left: 213*fem,
                                top: 110*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 46*fem,
                                    height: 22*fem,
                                    child: Text(
                                      '55 php',
                                      style: SafeGoogleFont (
                                        'Iceberg',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2941176471*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjabpGfT (DNZ6K9zQPSH4yNB6MdJaBP)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 21*fem, 21*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroup5i2hCJD (DNZ6REec6wBuHWBQkM5i2h)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 70*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(23*fem, 45*fem, 0*fem, 0*fem),
                          width: 65*fem,
                          child: Align(
                            // rectangle4X5b (1:348)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: double.infinity,
                              height: 38*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // sddefault1TV3 (1:355)
                          width: 218*fem,
                          height: 96*fem,
                          child: Image.asset(
                            'assets/page-1/images/sddefault-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupzdftbbF (DNZ6YKH9DwUvibXeDbZdfT)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17*fem),
                    padding: EdgeInsets.fromLTRB(35*fem, 1*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: 174*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupylpmheH (DNZ6gp2zAkEZEhwvP6YLpm)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 69*fem, 22*fem),
                          padding: EdgeInsets.fromLTRB(23*fem, 40*fem, 0*fem, 0*fem),
                          width: 65*fem,
                          child: Align(
                            // rectangle5R4V (1:349)
                            alignment: Alignment.bottomRight,
                            child: SizedBox(
                              width: double.infinity,
                              height: 38*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup9vhfYuo (DNZ6mE5JD4qjgb3iJw9Vhf)
                          width: 240*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroup5t8hhGu (DNZ6qPd2Q1bsMEK2U95T8h)
                                margin: EdgeInsets.fromLTRB(37*fem, 0*fem, 0*fem, 54*fem),
                                width: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // babyoctopustakoyakidgM (1:346)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                                      child: Text(
                                        'Baby Octopus Takoyaki',
                                        style: SafeGoogleFont (
                                          'Iceberg',
                                          fontSize: 17*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2941176471*ffem/fem,
                                          letterSpacing: -0.4079999924*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // phpixh (1:358)
                                      '80 php',
                                      style: SafeGoogleFont (
                                        'Iceberg',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2941176471*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // truruhy13zy (1:356)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                width: 217*fem,
                                height: 97*fem,
                                child: Image.asset(
                                  'assets/page-1/images/truruhy-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupuufbB5b (DNZ75U3uMZaEd14fV6UuFb)
                    margin: EdgeInsets.fromLTRB(220*fem, 0*fem, 8*fem, 52*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // scalloptakoyakihpd (1:350)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 0*fem),
                          child: Text(
                            'Scallop Takoyaki\n',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2941176471*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // phpDHB (1:357)
                          '75 php',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 17*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2941176471*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupaqf39gd (DNZ7BJDXDge29uEW7Baqf3)
                    margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 101*fem, 40*fem),
                    padding: EdgeInsets.fromLTRB(63*fem, 35*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: 102*fem,
                    child: Container(
                      // autogroupyprffus (DNZ7GDEzxkwJAG1FaHYPRf)
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xfff98bc7),
                        borderRadius: BorderRadius.circular(100*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Confirm Order',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 30*ffem,
                            fontWeight: FontWeight.w400,
                            height: 0.7333333333*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // homeindicator94M (I1:337;5:3093)
                    margin: EdgeInsets.fromLTRB(137*fem, 0*fem, 138*fem, 0*fem),
                    width: double.infinity,
                    height: 5*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}