import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax5nYR (1:367)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff8c8dc),
          borderRadius: BorderRadius.circular(50*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // statusbariphone13Vxd (1:368)
              padding: EdgeInsets.fromLTRB(34*fem, 0*fem, 33.6*fem, 0*fem),
              width: double.infinity,
              height: 63*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftside1AH (I1:368;708:6584)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 45*fem, 26*fem),
                    width: 54*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24*fem),
                    ),
                    child: Container(
                      // statusbartimej6H (I1:368;708:6585)
                      padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 12*fem, 0*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24*fem),
                      ),
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2941176471*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff010101),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // notchznu (I1:368;701:5663)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 33*fem),
                    width: 164*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/notch-tYR.png',
                      width: 164*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // rightsideJ2u (I1:368;708:8722)
                    margin: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 31*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iconmobilesignaloEZ (I1:368;708:9720)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 18*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-mobile-signal-Ujb.png',
                            width: 18*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // wifiuHb (I1:368;708:8727)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                          width: 17*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi-Yu7.png',
                            width: 17*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // battery1rR (I1:368;708:8723)
                          width: 27.4*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery-FNR.png',
                            width: 27.4*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupwrqmLth (DNZBhRBmFnjJM92kLWWrQM)
              padding: EdgeInsets.fromLTRB(34*fem, 45*fem, 5*fem, 15*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroup92sfTyK (DNZA7DLQ7ogcY7c5PB92sF)
                    margin: EdgeInsets.fromLTRB(33*fem, 0*fem, 33*fem, 13*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle3BuK (1:374)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 68*fem, 1*fem),
                          width: 42*fem,
                          height: 38*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-3.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // pf69hero1HxM (1:372)
                          width: 215*fem,
                          height: 93*fem,
                          child: Image.asset(
                            'assets/page-1/images/pf69-hero-1-T6R.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjkrmpBb (DNZAHHswTL8DL4z461jKrM)
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogrouppetx9jf (DNZAS38NFWitdREp29PETX)
                          margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 101*fem, 0*fem),
                          width: 79*fem,
                          height: 26*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // qty4bj (1:381)
                                left: 0*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 79*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'qty: ______',
                                      style: SafeGoogleFont (
                                        'Iceberg',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2941176471*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // 8bb (1:382)
                                left: 46*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 8*fem,
                                    height: 22*fem,
                                    child: Text(
                                      '2',
                                      style: SafeGoogleFont (
                                        'Iceberg',
                                        fontSize: 17*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2941176471*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // takoyakicheesebombcmf (1:373)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                          child: Text(
                            'Takoyaki Cheese Bomb',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2941176471*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // phpWc9 (1:383)
                          '65 php',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 17*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2941176471*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line3eTT (1:375)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
              width: double.infinity,
              height: 1*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
            ),
            Container(
              // autogroupkmo3ZqK (DNZAYx6WobnYsghPeJkMo3)
              margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 228*fem, 41*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupcg9kVU5 (DNZAi7Vv25Te96gHCACG9K)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 5*fem),
                    width: 14*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle41hK (1:378)
                          width: 14*fem,
                          height: 15*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-4.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          height: 7*fem,
                        ),
                        Container(
                          // rectangle5Ljb (1:379)
                          width: double.infinity,
                          height: 15*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        SizedBox(
                          height: 7*fem,
                        ),
                        Container(
                          // rectangle6rxq (1:380)
                          width: double.infinity,
                          height: 15*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // modeofpaymentgcashcreditcardde (1:377)
                    constraints: BoxConstraints (
                      maxWidth: 166*fem,
                    ),
                    child: Text(
                      'Mode of Payment:\n\nGcash\nCredit Card / Debit Card\nCash on Delivery',
                      style: SafeGoogleFont (
                        'Iceberg',
                        fontSize: 17*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2941176471*ffem/fem,
                        letterSpacing: -0.4079999924*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line4Txd (1:376)
              width: double.infinity,
              height: 1*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
            ),
            Container(
              // autogroupmundDgu (DNZBwQnSvt5z2VqZRvMuNd)
              padding: EdgeInsets.fromLTRB(11*fem, 22*fem, 11*fem, 22*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroup7mgzjQM (DNZAswYsWE4C9pDn8N7MgZ)
                    margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 20*fem, 48*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // menurUy (1:384)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 196*fem, 2*fem),
                          child: Text(
                            'Menu:',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 0.9166666667*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // viewtoaddorder9iy (1:391)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                          child: Text(
                            'View to Add order',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2941176471*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupwgd3STB (DNZB1XAaKz3K9PEy8swgD3)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 222*fem, 30*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle7Znh (1:386)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 3*fem),
                          width: 14*fem,
                          height: 15*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-7.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Text(
                          // takoyakicheesebombgsK (1:385)
                          'Takoyaki Cheese Bomb',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 17*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2941176471*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupc1fkd1s (DNZB8GULK9scCpotuxC1FK)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                    width: 79*fem,
                    height: 23*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // qty8zD (1:387)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 79*fem,
                              height: 22*fem,
                              child: Text(
                                'qty: ______',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2941176471*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // 2Ju (1:388)
                          left: 41*fem,
                          top: 1*fem,
                          child: Align(
                            child: SizedBox(
                              width: 8*fem,
                              height: 22*fem,
                              child: Text(
                                '2',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2941176471*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // totalprice130phpuNh (1:389)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                    child: Text(
                      'Total Price : 130 php',
                      style: SafeGoogleFont (
                        'Iceberg',
                        fontSize: 17*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2941176471*ffem/fem,
                        letterSpacing: -0.4079999924*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // modeofpaymentgcashzuw (1:390)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                    child: Text(
                      'Mode of Payment: Gcash',
                      style: SafeGoogleFont (
                        'Iceberg',
                        fontSize: 17*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2941176471*ffem/fem,
                        letterSpacing: -0.4079999924*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroup5wps7Um (DNZBEWnvba1ohnhs9m5wPs)
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // couponTYd (1:392)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 1*fem),
                          child: Text(
                            'Coupon:',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2941176471*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // rectangle8N9o (1:393)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 203*fem,
                          height: 21*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                        Container(
                          // browse6bb (1:394)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          child: Text(
                            'Browse',
                            style: SafeGoogleFont (
                              'Iceberg',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2941176471*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line5c49 (1:395)
              width: double.infinity,
              height: 1*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
            ),
            Container(
              // autogroupaw7xkg9 (DNZCGKQcM3jwiDR7zSAW7X)
              padding: EdgeInsets.fromLTRB(17*fem, 24*fem, 17*fem, 8*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupwfqzgZo (DNZBNviaFv9kdVBKPiWFQZ)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 183*fem, 44*fem),
                    width: 213*fem,
                    height: 69*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // ordernumberestimatedwaitingtim (1:396)
                          left: 0*fem,
                          top: 3*fem,
                          child: Align(
                            child: SizedBox(
                              width: 213*fem,
                              height: 66*fem,
                              child: Text(
                                'Order Number: ______________\nEstimated Waiting Time: _______',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2941176471*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // ordernumberestimatedwaitingtim (1:397)
                          left: 0*fem,
                          top: 3*fem,
                          child: Align(
                            child: SizedBox(
                              width: 213*fem,
                              height: 66*fem,
                              child: Text(
                                'Order Number: ______________\nEstimated Waiting Time: _______',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2941176471*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // minJDo (1:398)
                          left: 165*fem,
                          top: 23*fem,
                          child: Align(
                            child: SizedBox(
                              width: 45*fem,
                              height: 22*fem,
                              child: Text(
                                '20 min',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2941176471*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // k81dg5daah7 (1:399)
                          left: 124*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 67*fem,
                              height: 22*fem,
                              child: Text(
                                'K81dg5da',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2941176471*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupom81SjK (DNZBXAyqMM4LNMm7naom81)
                    margin: EdgeInsets.fromLTRB(82*fem, 0*fem, 85*fem, 21*fem),
                    width: double.infinity,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff9791e4),
                      borderRadius: BorderRadius.circular(50*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Place Order',
                        style: SafeGoogleFont (
                          'Iceberg',
                          fontSize: 36*ffem,
                          fontWeight: FontWeight.w400,
                          height: 0.6111111111*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // homeindicatorhQM (I1:369;5:3093)
                    margin: EdgeInsets.fromLTRB(131*fem, 0*fem, 131*fem, 0*fem),
                    width: double.infinity,
                    height: 5*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}