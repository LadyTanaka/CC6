import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax6oD3 (1:400)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff8c8dc),
          borderRadius: BorderRadius.circular(50*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbariphone13vHf (1:401)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 29*fem),
              padding: EdgeInsets.fromLTRB(34*fem, 0*fem, 33.6*fem, 0*fem),
              width: double.infinity,
              height: 63*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftsidebub (I1:401;708:6584)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 45*fem, 26*fem),
                    width: 54*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24*fem),
                    ),
                    child: Container(
                      // statusbartimevws (I1:401;708:6585)
                      padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 12*fem, 0*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24*fem),
                      ),
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2941176471*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff010101),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // notchnDP (I1:401;701:5663)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 33*fem),
                    width: 164*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/notch.png',
                      width: 164*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // rightsidesEq (I1:401;708:8722)
                    margin: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 31*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iconmobilesignalCH7 (I1:401;708:9720)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 18*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-mobile-signal.png',
                            width: 18*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // wifiWob (I1:401;708:8727)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                          width: 17*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi-2xH.png',
                            width: 17*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // batterydNR (I1:401;708:8723)
                          width: 27.4*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery.png',
                            width: 27.4*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // yourorderisgettingpreparedMJR (1:409)
              margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 0*fem, 17*fem),
              child: Text(
                'Your Order Is Getting Prepared',
                style: SafeGoogleFont (
                  'Iceberg',
                  fontSize: 32*ffem,
                  fontWeight: FontWeight.w400,
                  height: 0.6875*ffem/fem,
                  letterSpacing: -0.4079999924*fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // autogroup8zyjqUV (DNZDQNLtNwcHDc2M4v8zyj)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 14*fem, 24*fem),
              padding: EdgeInsets.fromLTRB(119*fem, 57*fem, 125*fem, 102*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(90*fem),
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-9-bg.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupolxo7gu (DNZDWHLhXXHkLv91cYoLXo)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 106*fem, 92*fem),
                    width: 52*fem,
                    height: 31*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // freepinicon48thumb1dv9 (1:405)
                          left: 19*fem,
                          top: 14*fem,
                          child: Align(
                            child: SizedBox(
                              width: 12*fem,
                              height: 17*fem,
                              child: Image.asset(
                                'assets/page-1/images/free-pin-icon-48-thumb-1.png',
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // deliveryman8M7 (1:406)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 52*fem,
                              height: 22*fem,
                              child: Text(
                                'Delivery Man',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 2.2*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // yourherecn5 (1:404)
                    margin: EdgeInsets.fromLTRB(117*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'Your Here',
                      style: SafeGoogleFont (
                        'Iceberg',
                        fontSize: 10*ffem,
                        fontWeight: FontWeight.w400,
                        height: 2.2*ffem/fem,
                        letterSpacing: -0.4079999924*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line4X8M (1:408)
              width: double.infinity,
              height: 1*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
            ),
            Container(
              // autogroupxtkqTXo (DNZDxBmCnEd3sK7yimXTkq)
              padding: EdgeInsets.fromLTRB(6*fem, 6*fem, 6*fem, 8*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupwrm3aMX (DNZDdhJ1nN3W9fGYmyWrm3)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 102*fem, 31*fem),
                    width: 316*fem,
                    height: 24*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // ordernumberhS9 (1:407)
                          left: 0*fem,
                          top: 2*fem,
                          child: Align(
                            child: SizedBox(
                              width: 316*fem,
                              height: 22*fem,
                              child: Text(
                                'Order Number: ______________\n',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 0.9166666667*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // k81dg5dayPf (1:410)
                          left: 174*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 96*fem,
                              height: 22*fem,
                              child: Text(
                                'K81dg5da',
                                style: SafeGoogleFont (
                                  'Iceberg',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 0.9166666667*ffem/fem,
                                  letterSpacing: -0.4079999924*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjbtj4g1 (DNZDjh82DQLesPL3F9jbTj)
                    margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 200*fem, 263*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // b0531c865bd8519b4adcc203c99f18 (1:411)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                          width: 63*fem,
                          height: 63*fem,
                          child: Image.asset(
                            'assets/page-1/images/b0531c865bd8519b4adcc203c99f182-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Text(
                          // minutesetaWH7 (1:412)
                          '20 Minutes eta\n',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w400,
                            height: 0.9166666667*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouph8iz329 (DNZDqSTSo4nkosZ3whH8iZ)
                    margin: EdgeInsets.fromLTRB(85*fem, 0*fem, 104*fem, 21*fem),
                    width: double.infinity,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                      borderRadius: BorderRadius.circular(50*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Go to homepage\n',
                        style: SafeGoogleFont (
                          'Iceberg',
                          fontSize: 32*ffem,
                          fontWeight: FontWeight.w400,
                          height: 0.6875*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // homeindicatorhMb (I1:402;5:3093)
                    margin: EdgeInsets.fromLTRB(142*fem, 0*fem, 142*fem, 0*fem),
                    width: double.infinity,
                    height: 5*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}