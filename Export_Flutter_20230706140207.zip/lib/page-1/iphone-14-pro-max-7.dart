import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax7w8m (1:415)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff8c8dc),
          borderRadius: BorderRadius.circular(50*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbariphone134UH (1:418)
              padding: EdgeInsets.fromLTRB(34*fem, 0*fem, 33.6*fem, 0*fem),
              width: double.infinity,
              height: 63*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftsideaBj (I1:418;708:6584)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 45*fem, 26*fem),
                    width: 54*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24*fem),
                    ),
                    child: Container(
                      // statusbartime6ZP (I1:418;708:6585)
                      padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 12*fem, 0*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(24*fem),
                      ),
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro Text',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2941176471*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff010101),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // notchZxm (I1:418;701:5663)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 33*fem),
                    width: 164*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/notch-Sho.png',
                      width: 164*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // rightsidesyT (I1:418;708:8722)
                    margin: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 31*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iconmobilesignalCkq (I1:418;708:9720)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 18*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-mobile-signal-3Qm.png',
                            width: 18*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // wifijEy (I1:418;708:8727)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                          width: 17*fem,
                          height: 12*fem,
                          child: Image.asset(
                            'assets/page-1/images/wifi-dDK.png',
                            width: 17*fem,
                            height: 12*fem,
                          ),
                        ),
                        Container(
                          // batteryTgm (I1:418;708:8723)
                          width: 27.4*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/battery-HGM.png',
                            width: 27.4*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroups3w5Noj (DNZExKkzrY3Y1Uvi6ZS3W5)
              padding: EdgeInsets.fromLTRB(38*fem, 33*fem, 34*fem, 42*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupgdsmJSV (DNZEev6LYdTs1CN29qgdSM)
                    margin: EdgeInsets.fromLTRB(13*fem, 0*fem, 0*fem, 33*fem),
                    padding: EdgeInsets.fromLTRB(59*fem, 55*fem, 59*fem, 56*fem),
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                      borderRadius: BorderRadius.circular(172.5*fem),
                    ),
                    child: Center(
                      // takoyaki1Piq (1:419)
                      child: SizedBox(
                        width: 227*fem,
                        height: 234*fem,
                        child: Image.asset(
                          'assets/page-1/images/takoyaki-1-n3b.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // takokianeykoso7uj (1:420)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 118*fem, 0*fem),
                    constraints: BoxConstraints (
                      maxWidth: 240*fem,
                    ),
                    child: Text(
                      'Takokian e yōkoso',
                      style: SafeGoogleFont (
                        'Imperial Script',
                        fontSize: 64*ffem,
                        fontWeight: FontWeight.w400,
                        height: 0.34375*ffem/fem,
                        letterSpacing: -0.4079999924*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkneqnW5 (DNZEk5cQ95cBnnyFPaKNeq)
              width: double.infinity,
              height: 219*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle11i8q (1:416)
                    left: 0*fem,
                    top: 137*fem,
                    child: Align(
                      child: SizedBox(
                        width: 107*fem,
                        height: 25*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffd9d9d9),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // pendingorderk81dg5daRJ9 (1:425)
                    left: 0*fem,
                    top: 93*fem,
                    child: Align(
                      child: SizedBox(
                        width: 366*fem,
                        height: 22*fem,
                        child: Text(
                          'Pending Order: K81dg5da...',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 0.6875*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // clicktoviewgzm (1:426)
                    left: 7*fem,
                    top: 137*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 22*fem,
                        child: Text(
                          'Click to view',
                          style: SafeGoogleFont (
                            'Iceberg',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.375*ffem/fem,
                            letterSpacing: -0.4079999924*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupyakuxhP (DNZF456RSCVdwy9io6yaku)
              padding: EdgeInsets.fromLTRB(99*fem, 68*fem, 102*fem, 8*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouptwffgdP (DNZEraRaGsbS4zhhQ1tWFF)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 51*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                      borderRadius: BorderRadius.circular(50*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Go Order',
                        style: SafeGoogleFont (
                          'Iceberg',
                          fontSize: 36*ffem,
                          fontWeight: FontWeight.w400,
                          height: 0.6111111111*ffem/fem,
                          letterSpacing: -0.4079999924*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // homeindicatorwJR (I1:421;5:3093)
                    margin: EdgeInsets.fromLTRB(49*fem, 0*fem, 46*fem, 0*fem),
                    width: double.infinity,
                    height: 5*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}